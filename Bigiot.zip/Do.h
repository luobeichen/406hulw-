/*******************
Do.h

*******************/

#ifndef _DO_H__
#define _DO_H__

//����Arduino����ͷ�ļ�
#include "Arduino.h"  
#include "EEPROM.h"
class DO
{
	private:
		bool remember;
	public:
		byte led3Pin, delayPin, sw1Pin, sw2Pin, delayStateAdd, delayState, modeState, modeStateAdd;
		DO();
		void init();
		void led3On();
		void led3Off();
		void delayOn();
		void delayOff();
		void set_remember(bool s = 1);
};

#endif
