/*******************
bigiot.h

*******************/

#ifndef _BIGIOT_H__
#define _BIGIOT_H__

//导入Arduino核心头文件
#include "Arduino.h"
#include "ESP8266WiFi.h"
#include "aJSON.h"

class BIGIOT
{
	private:
		bool debug;
	public:
		BIGIOT();
		WiFiClient client;
		void checkin(String id ,String key);
		void checkout(String id ,String key);
		void status();
		void say(String toId,String content,String sign = "");
		void update1(String did,String inputid,float value);
		void update2(String did,String inputid1,float value1,String inputid2,float value2);
		void update3(String did,String inputid1,float value1,String inputid2,float value2,String inputid3,float value3);
		void time(String format);
		void smartConfig(unsigned int ledPin = 0);
		aJsonObject *getJsonObj(String wifiInputString);
		void setDebug(bool d = false);
};
#endif
