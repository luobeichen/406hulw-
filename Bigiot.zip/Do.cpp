/*****************
Do.cpp

******************/

#include "Do.h"
#include "Arduino.h"
#include "EEPROM.h"

DO::DO()
{
	led3Pin=15;
	delayPin = 12;
	sw1Pin = 14;
	sw2Pin = 13;
	delayState = 0;
	modeState = 0;
	modeStateAdd = 1;
	delayStateAdd = 2;
	remember = true;
}

void DO::init()
{
	pinMode(led3Pin, OUTPUT);
	pinMode(delayPin, OUTPUT);
	pinMode(sw1Pin, INPUT_PULLUP);
	pinMode(sw2Pin, INPUT_PULLUP);
	EEPROM.begin(8);
	if (remember)
	{
		delayState = EEPROM.read(delayStateAdd);
		modeState = EEPROM.read(modeStateAdd);
		if(delayState == 1)digitalWrite(delayPin, HIGH);
		if(modeState == 1)digitalWrite(led3Pin, HIGH);
	}else
	{
		digitalWrite(delayPin, LOW);
		digitalWrite(led3Pin, LOW);
	}
}

void DO::set_remember(bool s)
{
	remember = s;
}

void DO::led3On()
{
	digitalWrite(led3Pin, HIGH);
	if (remember)
	{
		EEPROM.write(modeStateAdd, 1);
		EEPROM.commit();
	}
	
}
void DO::led3Off()
{
	digitalWrite(led3Pin, LOW);
	if (remember)
	{
		EEPROM.write(modeStateAdd, 0);
		EEPROM.commit();
	}
}
void DO::delayOn()
{
	digitalWrite(delayPin, HIGH);
	delayState = 1;
	if (remember)
	{
		EEPROM.write(delayStateAdd, 1);
		EEPROM.commit();
	}
		
}
void DO::delayOff()
{
	digitalWrite(delayPin, LOW);
	delayState = 0;
	if (remember)
	{
		EEPROM.write(delayStateAdd, 0);
		EEPROM.commit();
	}
		
}