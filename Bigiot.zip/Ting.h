/*******************
Ting.h

*******************/

#ifndef _TING_H__
#define _TING_H__

//导入Arduino核心头文件
#include"Arduino.h"  

class TING
{
	private:
		unsigned int Do, Re, Mi, Fa, So, La, Si;
	public:
		byte buzzerPin, ledPin;
		TING();
		void init();
		void set_once(unsigned int t=0);
		void set_continue();
		void set_group(unsigned int num);
		void exit();
		void sleep();
		void wakeup();
		void voice(unsigned int num=0, unsigned int sc=5);
		void ledOn();
		void ledOff();
		int get_command();
};

#endif
