/*****************
bigiot.cpp

******************/

#include "bigiot.h"
#include "Arduino.h"
#include "ESP8266WiFi.h"
#include "aJSON.h"

/*
bigiot.................
*/
BIGIOT::BIGIOT()
{
	client = WiFiClient();
}
void BIGIOT::status()
{
	client.print("{\"M\":\"status\"}\n");
	if(debug)Serial1.println("status");
}
void BIGIOT::checkin(String did,String apikey)
{
	client.print("{\"M\":\"checkin\",\"ID\":\"");
	client.print(did);
	client.print("\",\"K\":\"");
	client.print(apikey);
	client.print("\"}\n");
	if(debug)Serial1.println("checkin");
}
void BIGIOT::checkout(String did,String apikey)
{
	client.print("{\"M\":\"checkout\",\"ID\":\"");
	client.print(did);
	client.print("\",\"K\":\"");
	client.print(apikey);
	client.print("\"}\n");
	if(debug)Serial1.println("checkout");
}
void BIGIOT::say(String client_id, String content, String sign)
{
	client.print("{\"M\":\"say\",\"ID\":\"");
	client.print(client_id);
	client.print("\",\"C\":\"");
	client.print(content);
	if (sign != "")
	{
		client.print("\",\"SIGN\":\"");
		client.print(sign);
	}
	client.print("\"}\n");
	if(debug)Serial1.println("say");
}
void BIGIOT::update1(String did, String inputid, float value)
{
	client.print("{\"M\":\"update\",\"ID\":\"");
	client.print(did);
	client.print("\",\"V\":{\"");
	client.print(inputid);
	client.print("\":\"");
	client.print(value);
	client.println("\"}}");
	if(debug)Serial1.println("update1");
}
//同时上传两个接口数据调用此函数
void BIGIOT::update2(String did, String inputid1, float value1, String inputid2, float value2)
{
	client.print("{\"M\":\"update\",\"ID\":\"");
	client.print(did);
	client.print("\",\"V\":{\"");
	client.print(inputid1);
	client.print("\":\"");
	client.print(value1);
	client.print("\",\"");
	client.print(inputid2);
	client.print("\":\"");
	client.print(value2);
	client.println("\"}}");
	if(debug)Serial1.println("update2");
}
//同时上传三个接口数据调用此函数
void BIGIOT::update3(String did, String inputid1, float value1, String inputid2, float value2, String inputid3, float value3)
{
	client.print("{\"M\":\"update\",\"ID\":\"");
	client.print(did);
	client.print("\",\"V\":{\"");
	client.print(inputid1);
	client.print("\":\"");
	client.print(value1);
	client.print("\",\"");
	client.print(inputid2);
	client.print("\":\"");
	client.print(value2);
	client.print("\",\"");
	client.print(inputid3);
	client.print("\":\"");
	client.print(value3);
	client.println("\"}}");
	if(debug)Serial1.println("update3");
}
void BIGIOT::time(String format)
{
	client.print("{\"M\":\"time\",\"F\":\"");
	client.print(format);
	client.print("\"}\n");
	if(debug)Serial1.println("time");
}
void BIGIOT::smartConfig(unsigned int ledPin)
{
	WiFi.mode(WIFI_STA);
	if(debug)Serial1.println("Waiting for Smartconfig");
	//调用smartconfig功能
	WiFi.beginSmartConfig();
	unsigned long smartConfigBeginTime = millis();
	while (1)
	{
		Serial1.print(".");
		delay(1000);
		if(ledPin != 0)digitalWrite(ledPin, HIGH);
		delay(1000);
		if(ledPin != 0)digitalWrite(ledPin, LOW);
		//长时间等待smartconfig，自动退出
		if (millis() - smartConfigBeginTime > 300000)
		{
			break;
		}
		//若配置完成打印获取到的ssid
		if (WiFi.smartConfigDone())
		{
			delay(5000);
			if(debug)
			{
				Serial1.println("\r\nSmartConfig Success");
				Serial1.printf("SSID:%s\r\n", WiFi.SSID().c_str());
				Serial1.printf("PSWD:%s\r\n", WiFi.psk().c_str());
			}
			break;
		}
	}
}
aJsonObject *BIGIOT::getJsonObj(String wifiInputString)
{
	Serial1.print(wifiInputString);
	int jsonBeginAt = wifiInputString.indexOf("{");
	int jsonEndAt = wifiInputString.lastIndexOf("}");
	if (jsonBeginAt != -1 && jsonEndAt != -1)
	{
		wifiInputString = wifiInputString.substring(jsonBeginAt, jsonEndAt + 1);
		int len = wifiInputString.length() + 1;
		char jsonString[len];
		wifiInputString.toCharArray(jsonString, len);
		aJsonObject *msg = aJson.parse(jsonString);
		if(msg != NULL)return msg;
	}
	return NULL;
}
void BIGIOT::setDebug(bool d)
{
	debug = d;
}
