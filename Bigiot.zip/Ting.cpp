/*****************
Ting.cpp

******************/

#include "Ting.h"
#include "Arduino.h"

TING::TING()
{
	Do=262;
	Re=294;
	Mi=330;
	Fa=349;
	So=392;
	La=440;
	Si=494;
	buzzerPin=14;
	ledPin=12;
	pinMode(ledPin, OUTPUT);
	pinMode(buzzerPin, OUTPUT);
	digitalWrite(ledPin, HIGH);
}
void TING::init()
{
	Serial.write(0xA0);
	Serial.write(0xA0);
	Serial.write(0xA0);
	delay(248);
	Serial.write(0xA0);
	Serial.write(0xA0);
	Serial.write(0xA0);
}
void TING::set_once(unsigned int t)
{
	Serial.write(0xAA);
	Serial.write(t);
	Serial.write(0x00);
}
void TING::set_continue()
{
	Serial.write(0xAB);
	Serial.write(0xAB);
	Serial.write(0x00);
}
//<=255
void TING::set_group(unsigned int num)
{
	Serial.write(0xA9);
	Serial.write(num);
	Serial.write(0x00);
}
void TING::exit()
{
	Serial.write(0xAC);
	Serial.write(0xAC);
	Serial.write(0x00);
}
void  TING::sleep()
{
	Serial.write(0xAE);
	Serial.write(0xAE);
	Serial.write(0x00);
}
void TING::wakeup()
{
	Serial.write(0xA0);
	delay(248);
	Serial.write(0xA0);
	Serial.write(0xA0);
	Serial.write(0xA0);
	delay(50);
	Serial.write(0xA0);
	Serial.write(0xA0);
	Serial.write(0xA0);
}
void TING::voice(unsigned int num, unsigned int sc)
{
	switch(num){
		case 0:
			{
				int scale[] = {Do, Re, Re, La, Si, So, Re};
				for (int i = 0; i < 7; i++) {
					tone(buzzerPin, sc*scale[i]);
					delay(150);
					noTone(buzzerPin);
					delay(50);
				}
				
			}
			break;
		case 1:
			{
				int scale[] = {Do, Re, So, So};
				int delay_time[] = {200, 200, 400, 200};
				for (int i = 0; i < 4; i++) {
					tone(buzzerPin, sc*scale[i]);
					delay(delay_time[i]);
					noTone(buzzerPin);
					delay(50);
				}
			}
			break;
		default :
			{
				int scale[] = {Do, Do, So, So};
				int delay_time[] = {200, 200, 400, 200};
				for (int i = 0; i < 4; i++) {
					tone(buzzerPin, sc*scale[i]);
					delay(delay_time[i]);
					noTone(buzzerPin);
					delay(50);
				}
			}
			
			break;
	}
	
}
void TING::ledOn()
{
	digitalWrite(ledPin, LOW);
}
void TING::ledOff()
{
	digitalWrite(ledPin, HIGH);
}
/*
**-100 illegal command
**-1 init success
**-2 set success
*/
int TING::get_command()
{
	size_t num = Serial.available();
    if (num < 3)return -100;
    byte inByte = Serial.read();
    uint8_t sbuf[3];
    switch (inByte) {
      //初始成功
      case 0x50:
        Serial1.println("init command");
        sbuf[0] = inByte;
        sbuf[1] = Serial.read();
        if (sbuf[1] != 0x50)return -100;
        sbuf[2] = Serial.read();
        Serial1.print(sbuf[0], HEX);
        Serial1.print(sbuf[1], HEX);
        Serial1.println(sbuf[2], HEX);
		return -1;
      //麦克风灵敏度
      case 0x51:
        Serial1.println("mic command");
        sbuf[0] = inByte;
        sbuf[1] = Serial.read();
        sbuf[2] = Serial.read();
        Serial1.print(sbuf[0], HEX);
        Serial1.print(sbuf[1], HEX);
        Serial1.println(sbuf[2], HEX);
		return -2;
      //配置噪声、语音音量
      case 0x52:
        Serial1.println("voice command");
        sbuf[0] = inByte;
        sbuf[1] = Serial.read();
        sbuf[2] = Serial.read();
        Serial1.print(sbuf[0], HEX);
        Serial1.print(sbuf[1], HEX);
        Serial1.println(sbuf[2], HEX);
		return -2;
      //配置识别组
      case 0x59:
        Serial1.println("group command");
        sbuf[0] = inByte;
        sbuf[1] = Serial.read();
        sbuf[2] = Serial.read();
        Serial1.print(sbuf[0], HEX);
        Serial1.print(sbuf[1], HEX);
        Serial1.println(sbuf[2], HEX);
		return -2;
      //单次识别结果
      case 0x5a:
        Serial1.println("result command a");
        sbuf[0] = inByte;
        sbuf[1] = Serial.read();
        sbuf[2] = Serial.read();
        Serial1.print(sbuf[0], HEX);
        Serial1.print(sbuf[1], HEX);
        Serial1.println(sbuf[2], HEX);
        sbuf[2] = sbuf[2] << 8;
        Serial1.println(sbuf[1] + sbuf[2] + 1);
        return sbuf[1] + sbuf[2] + 1;
      //连续识别结果
      case 0x5b:
        Serial1.println("result command b");
        sbuf[0] = inByte;
        sbuf[1] = Serial.read();
        sbuf[2] = Serial.read();
        Serial1.print(sbuf[0], HEX);
        Serial1.print(sbuf[1], HEX);
        Serial1.println(sbuf[2], HEX);
        sbuf[2] = sbuf[2] << 8;
        Serial1.println(sbuf[1] + sbuf[2] + 1);
		return sbuf[1] + sbuf[2] + 1;
      default:
        Serial1.println("unknown");
		return 0;
    }
}
